﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Raet.Recruitment.Refactoring.Shapes
{
    public class TriangleShape : IShape
    {
        public string Name { get; set; }
        private double _width;

        public TriangleShape(double width)
        {
            Name = "TRIANGLE";
            _width = width;
        }

        public double GetArea()
        {
            return (Math.Sqrt(3) / 4) * _width * _width;
        }

        public double GetPerimeter()
        {
            return 3 * _width;
        }

        public double GetWidth()
        {
            return _width;
        }
    }
}
