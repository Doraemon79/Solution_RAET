﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Raet.Recruitment.Refactoring.Shapes
{
    public class NewShape
    {
   
        //public const int SQUARE = 1;
        //public const int CIRCLE = 2;
        //public const int TRIANGLE = 3;
         

        private readonly double width;
        public int type = -1;

        public NewShape(int type, double width)
        {
            this.type = type;
            this.width = width;
        }


        public double getWidth()
        {
            return width;
        }

    }
}
