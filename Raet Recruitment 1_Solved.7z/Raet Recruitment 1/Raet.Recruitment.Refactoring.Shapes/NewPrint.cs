﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Raet.Recruitment.Refactoring.Shapes
{
    public class NewPrint
    {
        public String Print(List<IShape> shapes)
        {
            String returnString = "";
            String squareString = "";
            String circlesString = "";
            String trianglesString = "";
            String xenoString = "";

            if (shapes.Count == 0)
            {
                returnString = "Empty list of shapes!";
            }
            else
            {
                Dictionary<string, int> objectcount = new Dictionary<string, int>();
                Dictionary<string, double> areascount = new Dictionary<string, double>();
                Dictionary<string, double> perimeterscount = new Dictionary<string, double>();
                objectcount["SQUARE"]=0;
                objectcount["CIRCLE"] = 0;
                objectcount["TRIANGLE"] = 0;
                objectcount["XENO"] = 0;
                areascount["SQUARE"] = 0;
                areascount["CIRCLE"] = 0;
                areascount["TRIANGLE"] = 0;
                areascount["XENO"] = 0;
                perimeterscount["SQUARE"] = 0;
                perimeterscount["CIRCLE"] = 0;
                perimeterscount["TRIANGLE"] = 0;
                perimeterscount["XENO"] = 0;

                // Compute calculations
                for (int i = 0; i < shapes.Count; i++)
                {

                    objectcount[shapes[i].Name] += 1;
                    areascount[shapes[i].Name] += shapes[i].GetArea();
                    perimeterscount[shapes[i].Name] += shapes[i].GetPerimeter();


                }
                var numberSquares = objectcount["SQUARE"];
                var numberCircles = objectcount["CIRCLE"];
                var numberTriangles = objectcount["TRIANGLE"];
                var numberXeno = objectcount["XENO"];
                // Get texts to print.
                if (numberSquares > 0)
                {
                    squareString = "Squares: " + numberSquares + ", Area: " + areascount["SQUARE"].ToString("#.##") + ", Perimeter: " + perimeterscount["SQUARE"].ToString("#.##") + ".";
                }

                if (numberCircles > 0)
                {
                    circlesString = "Circles: " + numberCircles + ", Area: " + areascount["CIRCLE"].ToString("#.##") + ", Perimeter: " + perimeterscount["CIRCLE"].ToString("#.##") + ".";
                }

                if (numberTriangles > 0)
                {
                    trianglesString = "Triangles: " + numberTriangles + ", Area: " + areascount["TRIANGLE"].ToString("#.##") + ", Perimeter: " + perimeterscount["TRIANGLE"].ToString("#.##") + ".";
                }
                if (numberXeno > 0)
                {
                    xenoString = "Xeno: " + numberXeno + ", Area: " + areascount["XENO"].ToString("#.##") + ", Perimeter: " + perimeterscount["XENO"].ToString("#.##") + ".";
                }

                var sortedDict = from entry in objectcount orderby entry.Value ascending select entry;

                if ((numberSquares == numberCircles)&& numberCircles == numberTriangles)
                { returnString = squareString + "\n" + circlesString + "\n" + trianglesString + "\n"; }
                else
                {
                    foreach (var elem in sortedDict)


                        switch (elem.Key)
                        {
                            case "SQUARE":
                                returnString = squareString + "\n"+ returnString;
                                break;
                            case "CIRCLE":
                                returnString = circlesString + "\n"+ returnString;
                                break;
                            case "TRIANGLE":
                                returnString = trianglesString + "\n"+ returnString;
                                break;
                            case "XENO":
                                returnString = xenoString + "\n" + returnString;
                                break;

                        }
                }
            }

            return returnString.Trim();
        }

    }
}
