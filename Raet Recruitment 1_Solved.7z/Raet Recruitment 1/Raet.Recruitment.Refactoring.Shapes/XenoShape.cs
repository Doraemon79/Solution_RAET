﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Raet.Recruitment.Refactoring.Shapes
{
   public class XenoShape : IShape
    {
        public string Name { get; set; }
        private double _width;


        public XenoShape(double width)
        {
            Name = "XENO";
            _width = width;
        }

        public double GetArea()
        {
            return _width * _width+0.11;
        }

        public double GetPerimeter()
        {
            return 26 * _width;
        }

        public double GetWidth()
        {
            return _width;
        }
    }
}
