﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Raet.Recruitment.Refactoring.Shapes
{
   public class CircleShape: IShape
    {
        public string Name { get; set; }
        private double _width;

        public CircleShape(double width)
        {
            Name = "CIRCLE";
            _width = width;
        }

        public double GetArea()
        {
            return Math.PI * (_width / 2) * (_width / 2);
        }

        public double GetPerimeter()
        {
            return Math.PI * _width;
        }

        public double GetWidth()
        {
            return _width;
        }
    }
}
