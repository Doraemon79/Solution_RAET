﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Raet.Recruitment.Refactoring.Shapes
{
    public class SquareShape : IShape
    {
        public string Name { get; set; }
        private double _width;


        public SquareShape(double width)
        {
            Name = "SQUARE";
            _width = width;
        }

        public double GetArea()
        {
            return _width * _width;
        }

        public double GetPerimeter()
        {
            return 4 * _width;
        }

        public double GetWidth()
        {
            return _width;
        }
    }
}
