﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Raet.Recruitment.Refactoring.Shapes
{
    [TestClass()]
    public class ShapeTest
    {
        private List<IShape> _shapes;
        private NewPrint _printer=new NewPrint();

        [TestInitialize]
        public void Initialize()
        {
            _shapes = new List<IShape>();
        }

        [TestMethod]
        public void givenEmptyList_whenPrint_thenReturnEmptyMessage()
        {
            Assert.AreEqual("Empty list of shapes!", _printer.Print(_shapes));
        }

        [TestMethod]
        public void givenOneSquare_whenPrint_thenReturnShapePrint()
        {
            _shapes.Add(new SquareShape( 2));
            Assert.AreEqual("Squares: 1, Area: 4, Perimeter: 8.", _printer.Print(_shapes));
        }

        [TestMethod]
        public void givenOneShapePerType_whenPrint_thenReturnOrderedShapesPrint()
        {
            _shapes.Add(new TriangleShape( 3));
            _shapes.Add(new SquareShape( 1));
            _shapes.Add(new CircleShape( 2));
            Assert.AreEqual("Squares: 1, Area: 1, Perimeter: 4.\nCircles: 1, Area: 3.14, Perimeter: 6.28.\nTriangles: 1, Area: 3.9, Perimeter: 9.", _printer.Print(_shapes));
        }

        [TestMethod]
        public void givenMultipleShapes_whenPrint_thenReturnOrderedSumShapesPrint()
        {
            _shapes.Add(new SquareShape( 1));
            _shapes.Add(new TriangleShape( 8));
            _shapes.Add(new CircleShape( 2));
            _shapes.Add(new TriangleShape( 3));
            _shapes.Add(new CircleShape( 4));
            _shapes.Add(new CircleShape( 2));
            _shapes.Add(new CircleShape( 3));
            _shapes.Add(new SquareShape( 3));
            _shapes.Add(new TriangleShape( 1));
            _shapes.Add(new XenoShape( 9));
            Assert.AreEqual("Circles: 4, Area: 25.92, Perimeter: 34.56.\nTriangles: 3, Area: 32.04, Perimeter: 36.\nSquares: 2, Area: 10, Perimeter: 16.\nXeno: 1, Area: 81.11, Perimeter: 234.", _printer.Print(_shapes));
        }
    }
}
