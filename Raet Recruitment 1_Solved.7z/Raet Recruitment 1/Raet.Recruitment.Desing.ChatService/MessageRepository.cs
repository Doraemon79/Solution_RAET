﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatLibrary
{
    public class MessageRepository : IRepository<Message>
    {
        public void Add(Message ent)
        {
            throw new NotImplementedException();
        }

        public List<Message> GetAll()
        {
            throw new NotImplementedException();
        }

        public void Remove(Message ent)
        {
            throw new NotImplementedException();
        }
    }
}
