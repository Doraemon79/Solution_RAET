﻿namespace ChatLibrary
{
    public class Group {
        public IRepository<User> Members { get; set; }
        public IRepository<Message> Messages {get;set;}
    }

}
