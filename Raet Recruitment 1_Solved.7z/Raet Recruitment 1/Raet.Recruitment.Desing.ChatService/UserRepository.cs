﻿using System;
using System.Collections.Generic;

namespace ChatLibrary
{
    public class UserRepository : IRepository<User>
    {
        private List<User> Users;
        public UserRepository()
        {
            Users = new List<User>();
        }
        public void Add(User user)
        {
            Users.Add(user);
        }

        public List<User> GetAll()
        {
            return Users;
        }

        public void Remove(User user)
        {
            Users.Remove(user);
        }
    }
}