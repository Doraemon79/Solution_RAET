﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatLibrary
{
    public class MessageHub
    {
        public event PrivateMessageHandler PrivateMessageReceived;
        public event GroupMessageHandler GroupMessageReceieved;

        public void SendMessage(User recipient, Message message)
        {
            PrivateMessageReceived(recipient, message);
        }
        public void SendMessage(Group recipient, Message message)
        {
            GroupMessageReceieved(recipient, message);
        }
    }

    public delegate EventHandler GroupMessageHandler(Group group, Message msg);
    public delegate EventHandler PrivateMessageHandler(User user, Message msg);

   
}
