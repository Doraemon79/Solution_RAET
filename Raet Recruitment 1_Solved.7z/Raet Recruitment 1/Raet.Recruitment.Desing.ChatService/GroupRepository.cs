﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatLibrary
{
    public class GroupRepository : IRepository<Group>
    {
        private List<Group> _groups = new List<Group>();
        public void Add(Group ent)
        {
            _groups.Add(ent);
        }

        public List<Group> GetAll()
        {
            return _groups;
        }

        public void Remove(Group ent)
        {
            _groups.Remove(ent);
        }
    }
}
