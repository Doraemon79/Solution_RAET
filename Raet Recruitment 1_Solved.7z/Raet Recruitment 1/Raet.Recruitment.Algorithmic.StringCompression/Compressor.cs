﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Raet.Recruitment.Algorithmic.StringCompression
{
    public class Compressor
    {
        public string Compress(string input)
        {
            if (String.IsNullOrEmpty(input))
                return string.Empty;

            int count = 0;
            int charCount = 0;
            string lastLetter = string.Empty;
            string outstring = string.Empty;
            while (count <= input.Length-1)
            {
                if (String.IsNullOrEmpty(lastLetter))
                {
                    lastLetter = input[count].ToString();
                    charCount++;
                    outstring += lastLetter;
                }
                else if (lastLetter == input[count].ToString())
                {
                    charCount++;
                }
                else
                {
                    outstring += charCount>10? 
                        "0"+lastLetter+( charCount%10).ToString():
                        charCount.ToString();
                    outstring += input[count];
                   lastLetter = input[count].ToString();
                    charCount = 1;
                }
                count++;
            }
            if (charCount > 0)
            {
                outstring += charCount > 10 ? 0 : charCount;
            }
            return outstring.Length>=input.Length?input:outstring;
        }
    }
}
